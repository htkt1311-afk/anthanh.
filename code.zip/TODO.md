# TODO — Excel QR

## Tải Excel, xem trước và tạo QR
- [x] Tải Excel, chọn sheet, xem dữ liệu, chọn/ghép trường và tạo QR cục bộ trong trình duyệt.
- [x] Tải từng QR hoặc gói ZIP có ảnh QR, CSV và PDF A4.
- [x] PDF và in trực tiếp dùng bảng 4 cột QR/tên sản phẩm/số lượng/trạng thái; tối đa 15 dòng/trang A4 dọc, lề 10 mm bốn cạnh, QR độ phân giải cao.
- [x] List box trạng thái lọc các dòng trước khi xuất.

## Đăng nhập duy nhất từ workbook
- [x] Dùng `Sheet1` của `FileDangnhap.xlsx`; dòng 1 là tiêu đề, cột A là username, cột B là password theo giá trị đang hiển thị trong Excel.
- [x] Gộp cặp đăng nhập trùng y hệt ở dòng 6 và 17; chỉ nhập 18 username duy nhất, không xuất username/password hoặc password hash vào log, file frontend hay Git.
- [x] Dòng Excel số 9 được cấp vai trò admin; các dòng còn lại là user đã duyệt.
- [x] Gỡ UI/API đăng ký và bootstrap; đăng nhập bằng username/password, không còn endpoint đăng ký hoạt động và hai secret bootstrap cũ đã bị thu hồi.
- [x] Mật khẩu được băm scrypt trong MySQL; giữ CSRF và cookie session HttpOnly/Secure/SameSite=None; login/session API chỉ chấp nhận username trong danh sách có status `approved`.
- [x] Giữ nguyên user cũ ngoài file nhưng chặn đăng nhập vì không có username; admin API chỉ liệt kê user có username trong file.
- [x] Tài khoản dòng 9 duy nhất có role admin; xác minh đăng nhập thành công cho dòng 2 và 9, admin API liệt kê đúng 17 user thường; mọi phiên kiểm thử đã logout/thu hồi.
- [x] Build, readiness, routes, CSRF, endpoint admin bị chặn khi chưa đăng nhập, đăng ký trả 404 và credentials trong workbook không được ghi vào frontend hoặc Git.

## Hardening trước khi mở công khai
- [ ] Thêm rate limiting/monitoring cho đăng nhập trước khi public; website hiện chưa publish.

## Lưu trữ và giao nhận
- [ ] Đích GitHub cụ thể và xác nhận chuyển mã vẫn đang chờ người dùng; không chuyển code sang repository khác trước khi xác nhận.
