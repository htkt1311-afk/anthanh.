export type AccountStatus = 'pending' | 'approved' | 'rejected';
export type AccountRole = 'user' | 'admin';

export type AuthUser = {
  id: string;
  username: string;
  displayName: string;
  role: AccountRole;
  status: AccountStatus;
  rejectionReason: string | null;
  createdAt: string;
};
