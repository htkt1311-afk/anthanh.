import { useCallback, useEffect, useState } from 'react';
import { BadgeCheck, Check, Clock3, LogOut, RefreshCw, ShieldCheck, Users, XCircle } from 'lucide-react';
import { authApi } from './api';
import { AuthFrame } from './AuthScreens';
import type { AccountStatus, AuthUser } from './types';

const STATUS_TABS: { value: AccountStatus | 'all'; label: string }[] = [
  { value: 'pending', label: 'Chờ duyệt' },
  { value: 'approved', label: 'Đã duyệt' },
  { value: 'rejected', label: 'Đã từ chối' },
  { value: 'all', label: 'Tất cả' },
];

function explain(error: unknown): string {
  return error instanceof Error ? error.message : 'Không thể tải danh sách tài khoản.';
}

function formatDate(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('vi-VN', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

export function AdminDashboard({ admin, onExit, onLogout, actionError }: { admin: AuthUser; onExit: () => void; onLogout: () => Promise<void>; actionError: string }) {
  const [filter, setFilter] = useState<AccountStatus | 'all'>('pending');
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState('');
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [loggingOut, setLoggingOut] = useState(false);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    setError('');
    try { setUsers(await authApi.listUsers(filter)); }
    catch (caught) { setError(explain(caught)); }
    finally { setLoading(false); }
  }, [filter]);

  useEffect(() => { void loadUsers(); }, [loadUsers]);

  async function decide(user: AuthUser, status: 'approved' | 'rejected') {
    setBusyId(user.id);
    setError('');
    setNotice('');
    try {
      await authApi.decideUser(user.id, status, status === 'rejected' ? (reasons[user.id] ?? '').trim() : '');
      setNotice(status === 'approved' ? `Đã duyệt tài khoản ${user.username}.` : `Đã từ chối tài khoản ${user.username}.`);
      setReasons((current) => { const next = { ...current }; delete next[user.id]; return next; });
      await loadUsers();
    } catch (caught) {
      setError(explain(caught));
    } finally {
      setBusyId('');
    }
  }

  async function logout() {
    setLoggingOut(true);
    try { await onLogout(); } catch { setLoggingOut(false); }
  }

  return <AuthFrame headerRight={<div className="admin-header-actions"><span className="admin-signed-in"><ShieldCheck size={14} />{admin.username}</span><button className="auth-quiet-button" type="button" onClick={onExit}>Excel QR</button><button className="auth-quiet-button" type="button" onClick={() => void logout()} disabled={loggingOut}><LogOut size={14} />{loggingOut ? 'Đang thoát…' : 'Thoát'}</button></div>}>
    <section className="admin-page">
      <div className="admin-heading"><div><span className="section-kicker">QUẢN TRỊ TÀI KHOẢN</span><h1>Duyệt thành viên.</h1><p>Chỉ tài khoản admin đã xác thực mới có thể thay đổi trạng thái.</p></div><span className="admin-heading-icon"><Users size={22} /></span></div>
      <div className="admin-toolbar"><div className="admin-tabs" role="tablist" aria-label="Lọc tài khoản">{STATUS_TABS.map((tab) => <button type="button" role="tab" aria-selected={filter === tab.value} className={filter === tab.value ? 'is-active' : ''} onClick={() => { setFilter(tab.value); setNotice(''); }} key={tab.value}>{tab.label}</button>)}</div><button className="admin-refresh" type="button" onClick={() => void loadUsers()} disabled={loading}><RefreshCw size={14} className={loading ? 'auth-spinner' : ''} />Làm mới</button></div>
      {notice && <div className="auth-success" role="status"><BadgeCheck size={15} />{notice}</div>}
      {(error || actionError) && <div className="auth-error" role="alert"><XCircle size={15} /><span>{error || actionError}</span></div>}
      {loading ? <div className="admin-empty"><RefreshCw size={19} className="auth-spinner" /><span>Đang tải danh sách…</span></div> : users.length ? <div className="admin-user-list">{users.map((user) => <article className="admin-user-card" key={user.id}>
        <div className="admin-user-top"><div className="admin-user-identity"><span className="admin-avatar">{(user.displayName || user.username).slice(0, 1).toUpperCase()}</span><div><strong>{user.displayName || user.username}</strong><span>{user.username}</span></div></div><span className={`admin-status status-${user.status}`}>{user.status === 'pending' ? <Clock3 size={12} /> : user.status === 'approved' ? <Check size={12} /> : <XCircle size={12} />}{user.status === 'pending' ? 'Chờ duyệt' : user.status === 'approved' ? 'Đã duyệt' : 'Đã từ chối'}</span></div>
        <div className="admin-user-meta">Tài khoản {formatDate(user.createdAt)}{user.rejectionReason ? <span> · Lý do từ chối: {user.rejectionReason}</span> : null}</div>
        {user.status === 'pending' && <><label className="admin-reason-label" htmlFor={`reason-${user.id}`}>Lý do từ chối <small>(tùy chọn)</small></label><textarea id={`reason-${user.id}`} className="admin-reason-input" value={reasons[user.id] ?? ''} onChange={(event) => setReasons((current) => ({ ...current, [user.id]: event.target.value }))} maxLength={500} rows={2} placeholder="Ví dụ: vui lòng xác nhận lại thông tin" /><div className="admin-decision-actions"><button className="admin-approve" type="button" onClick={() => void decide(user, 'approved')} disabled={busyId === user.id}><Check size={14} />{busyId === user.id ? 'Đang lưu…' : 'Duyệt tài khoản'}</button><button className="admin-reject" type="button" onClick={() => void decide(user, 'rejected')} disabled={busyId === user.id}><XCircle size={14} />{busyId === user.id ? 'Đang lưu…' : 'Từ chối'}</button></div></>}
      </article>)}</div> : <div className="admin-empty"><Users size={23} /><strong>Chưa có tài khoản trong mục này.</strong><span>Tài khoản được quản lý từ danh sách đã cấp.</span></div>}
    </section>
  </AuthFrame>;
}
