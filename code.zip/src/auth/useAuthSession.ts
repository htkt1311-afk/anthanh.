import { useCallback, useEffect, useState } from 'react';
import { ApiError, authApi, prepareCsrf } from './api';
import type { AuthUser } from './types';

function errorMessage(error: unknown): string {
  if (error instanceof ApiError || error instanceof Error) return error.message;
  return 'Không thể kết nối đến dịch vụ tài khoản. Hãy thử lại.';
}

export function useAuthSession() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectionError, setConnectionError] = useState('');
  const [actionError, setActionError] = useState('');

  const refresh = useCallback(async (showLoading = false): Promise<AuthUser | null> => {
    if (showLoading) setLoading(true);
    try {
      await prepareCsrf();
      const nextUser = await authApi.session();
      setUser(nextUser);
      setConnectionError('');
      return nextUser;
    } catch (error) {
      setUser(null);
      setConnectionError(errorMessage(error));
      return null;
    } finally {
      if (showLoading) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh(true);
    const interval = window.setInterval(() => { void refresh(false); }, 30_000);
    const onVisibility = () => { if (document.visibilityState === 'visible') void refresh(false); };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [refresh]);

  const login = useCallback(async (username: string, password: string) => {
    setActionError('');
    try {
      const nextUser = await authApi.login(username, password);
      setUser(nextUser);
      setConnectionError('');
    } catch (error) {
      setActionError(errorMessage(error));
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    setActionError('');
    try {
      await authApi.logout();
      setUser(null);
      setConnectionError('');
    } catch (error) {
      setActionError(errorMessage(error));
      throw error;
    }
  }, []);

  return { user, loading, connectionError, actionError, setActionError, refresh, login, logout };
}
