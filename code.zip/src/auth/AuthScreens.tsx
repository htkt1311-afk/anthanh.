import { useState, type FormEvent, type ReactNode } from 'react';
import { Clock3, FileSpreadsheet, LockKeyhole, LogIn, LogOut, QrCode, RefreshCw, ShieldCheck, XCircle } from 'lucide-react';
import type { AuthUser } from './types';

function BrandMark() {
  return <a className="brand" href="/" aria-label="Excel QR — trang chính"><span className="brand-mark"><FileSpreadsheet size={23} strokeWidth={2.3} /><span className="brand-qr"><QrCode size={13} strokeWidth={2.7} /></span></span><span className="brand-copy"><strong>excel<span>qr</span></strong><small>mã hóa gọn gàng</small></span></a>;
}

export function AuthFrame({ children, headerRight }: { children: ReactNode; headerRight?: ReactNode }) {
  return <div className="auth-shell"><header className="topbar auth-topbar page-wrap"><BrandMark /><div className="auth-header-right">{headerRight ?? <span className="privacy-pill"><span className="privacy-dot" /> Khu vực tài khoản</span>}</div></header><main className="auth-main page-wrap">{children}</main><footer className="footer page-wrap"><span>Excel QR · Riêng tư từ đầu</span><span>Hỗ trợ đăng nhập an toàn</span></footer></div>;
}

export function AuthLoadingScreen() {
  return <AuthFrame><section className="auth-status-card"><span className="auth-status-icon is-info"><RefreshCw size={22} className="auth-spinner" /></span><span className="section-kicker">ĐANG KIỂM TRA</span><h1>Đang mở phiên an toàn.</h1><p>Excel QR đang xác minh quyền truy cập của bạn.</p></section></AuthFrame>;
}

export function AuthConnectionScreen({ message, onRetry }: { message: string; onRetry: () => Promise<unknown> }) {
  const [busy, setBusy] = useState(false);
  async function retry() {
    setBusy(true);
    try { await onRetry(); } finally { setBusy(false); }
  }
  return <AuthFrame><section className="auth-status-card"><span className="auth-status-icon is-error"><XCircle size={23} /></span><span className="section-kicker">CHƯA KẾT NỐI ĐƯỢC</span><h1>Dịch vụ tài khoản tạm thời chưa sẵn sàng.</h1><p>{message}</p><button className="auth-primary" type="button" onClick={() => void retry()} disabled={busy}><RefreshCw size={15} className={busy ? 'auth-spinner' : ''} />{busy ? 'Đang thử lại…' : 'Thử kết nối lại'}</button></section></AuthFrame>;
}

type AuthPortalProps = {
  onLogin: (username: string, password: string) => Promise<void>;
  actionError: string;
  clearError: () => void;
};

export function AuthPortal({ onLogin, actionError, clearError }: AuthPortalProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    clearError();
    setBusy(true);
    try {
      await onLogin(username.trim(), password);
      setPassword('');
    } catch {
      setPassword('');
    } finally {
      setBusy(false);
    }
  }

  return <AuthFrame><div className="auth-layout"><section className="auth-intro"><span className="section-kicker">TÀI KHOẢN EXCEL QR</span><h1>Đăng nhập,<br /><em>làm việc tiếp.</em></h1><p>Chỉ tài khoản được cấp trong danh sách quản trị mới có thể truy cập. File Excel và mã QR vẫn được xử lý ngay trên thiết bị.</p><div className="auth-benefit"><span><LockKeyhole size={17} /></span><div><strong>Mật khẩu được bảo vệ</strong><small>Máy chủ chỉ lưu bản băm scrypt, không lưu mật khẩu nguyên văn.</small></div></div><div className="auth-benefit"><span><ShieldCheck size={17} /></span><div><strong>Quyền truy cập có kiểm soát</strong><small>Quyền quản trị chỉ được cấp cho tài khoản đã định danh.</small></div></div></section><section className="auth-card"><div className="auth-card-heading"><span className="auth-card-icon"><LogIn size={18} /></span><div><span className="label-overline">CHÀO MỪNG TRỞ LẠI</span><h2>Vào tài khoản</h2></div></div><form className="auth-form" onSubmit={(event) => void submit(event)}>
    <label className="auth-field"><span>Tên đăng nhập</span><input type="text" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" autoCapitalize="none" spellCheck={false} required maxLength={100} placeholder="Nhập tên đăng nhập" /></label>
    <label className="auth-field"><span>Mật khẩu</span><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" required maxLength={128} placeholder="Nhập mật khẩu" /></label>
    {actionError && <div className="auth-error" role="alert"><XCircle size={15} /><span>{actionError}</span></div>}
    <button className="auth-primary" type="submit" disabled={busy}>{busy ? <RefreshCw size={15} className="auth-spinner" /> : <LogIn size={15} />}{busy ? 'Đang xác thực…' : 'Đăng nhập an toàn'}</button>
    </form></section></div></AuthFrame>;
}

export function AccountStatusScreen({ user, onLogout, onRefresh, actionError }: { user: AuthUser; onLogout: () => Promise<void>; onRefresh: () => Promise<AuthUser | null>; actionError: string }) {
  const [refreshing, setRefreshing] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  async function refresh() {
    setRefreshing(true);
    try { await onRefresh(); } finally { setRefreshing(false); }
  }
  async function logout() {
    setLoggingOut(true);
    try { await onLogout(); } catch { /* The session hook exposes a localized error message. */ } finally { setLoggingOut(false); }
  }

  const rejected = user.status === 'rejected';
  return <AuthFrame headerRight={<button className="auth-quiet-button" type="button" onClick={() => void logout()} disabled={loggingOut}><LogOut size={14} />{loggingOut ? 'Đang thoát…' : 'Đăng xuất'}</button>}><section className="auth-status-card"><span className={`auth-status-icon ${rejected ? 'is-error' : 'is-warning'}`}>{rejected ? <XCircle size={23} /> : <Clock3 size={23} />}</span><span className="section-kicker">TÀI KHOẢN · {user.username}</span><h1>{rejected ? 'Quyền truy cập đã bị từ chối.' : 'Tài khoản chưa được duyệt.'}</h1><p>{rejected ? 'Hãy liên hệ quản trị viên nếu bạn cho rằng đây là nhầm lẫn.' : 'Quyền sử dụng Excel QR chưa được mở cho tài khoản này.'}</p>{user.rejectionReason && <blockquote className="rejection-reason">Lý do: {user.rejectionReason}</blockquote>}{actionError && <div className="auth-error" role="alert"><XCircle size={15} /><span>{actionError}</span></div>}<div className="auth-status-actions"><button className="auth-primary" type="button" onClick={() => void refresh()} disabled={refreshing}><RefreshCw size={15} className={refreshing ? 'auth-spinner' : ''} />{refreshing ? 'Đang kiểm tra…' : 'Kiểm tra trạng thái'}</button><button className="auth-secondary" type="button" onClick={() => void logout()} disabled={loggingOut}><LogOut size={14} />Đăng xuất</button></div><small className="auth-poll-note">Trạng thái được kiểm tra tự động mỗi 30 giây.</small></section></AuthFrame>;
}
