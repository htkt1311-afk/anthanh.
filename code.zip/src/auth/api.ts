import type { AuthUser, AccountStatus } from './types';

type ApiPayload = {
  user?: AuthUser | null;
  users?: AuthUser[];
  csrfToken?: string;
  error?: string;
  code?: string;
};

export class ApiError extends Error {
  code: string;
  constructor(message: string, code = 'REQUEST_FAILED') {
    super(message);
    this.name = 'ApiError';
    this.code = code;
  }
}

let csrfToken = '';
let csrfRequest: Promise<string> | null = null;

async function parsePayload(response: Response): Promise<ApiPayload> {
  try { return await response.json() as ApiPayload; } catch { return {}; }
}

async function loadCsrfToken(): Promise<string> {
  const response = await fetch('/api/auth/csrf', { method: 'GET', credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
  const payload = await parsePayload(response);
  if (!response.ok || !payload.csrfToken) throw new ApiError(payload.error || 'Không thể khởi tạo phiên bảo mật. Hãy thử tải lại trang.', payload.code);
  csrfToken = payload.csrfToken;
  return csrfToken;
}

export async function prepareCsrf(): Promise<string> {
  if (csrfToken) return csrfToken;
  if (!csrfRequest) csrfRequest = loadCsrfToken().finally(() => { csrfRequest = null; });
  return csrfRequest;
}

async function getJson(path: string): Promise<ApiPayload> {
  const response = await fetch(path, { method: 'GET', credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
  const payload = await parsePayload(response);
  if (!response.ok) throw new ApiError(payload.error || 'Không thể tải dữ liệu. Hãy thử lại.', payload.code);
  return payload;
}

async function sendJson(path: string, body: unknown, allowRetry = true): Promise<ApiPayload> {
  const token = await prepareCsrf();
  const response = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    cache: 'no-store',
    headers: { Accept: 'application/json', 'Content-Type': 'application/json', 'X-ExcelQR-CSRF': token },
    body: JSON.stringify(body),
  });
  const payload = await parsePayload(response);
  if (response.status === 403 && payload.code === 'CSRF_INVALID' && allowRetry) {
    csrfToken = '';
    await prepareCsrf();
    return sendJson(path, body, false);
  }
  if (!response.ok) throw new ApiError(payload.error || 'Không thể xử lý yêu cầu. Hãy thử lại.', payload.code);
  return payload;
}

export const authApi = {
  async session(): Promise<AuthUser | null> {
    const payload = await getJson('/api/auth/me');
    return payload.user ?? null;
  },
  async login(username: string, password: string): Promise<AuthUser> {
    const payload = await sendJson('/api/auth/login', { username, password });
    if (!payload.user) throw new ApiError('Không nhận được thông tin tài khoản.', 'INVALID_RESPONSE');
    return payload.user;
  },
  async logout(): Promise<void> { await sendJson('/api/auth/logout', {}); },
  async listUsers(status: AccountStatus | 'all'): Promise<AuthUser[]> {
    const payload = await getJson(`/api/admin/users?status=${encodeURIComponent(status)}`);
    return payload.users ?? [];
  },
  async decideUser(id: string, status: 'approved' | 'rejected', reason = ''): Promise<AuthUser> {
    const payload = await sendJson(`/api/admin/users/${encodeURIComponent(id)}/decision`, { status, reason });
    if (!payload.user) throw new ApiError('Không nhận được kết quả xét duyệt.', 'INVALID_RESPONSE');
    return payload.user;
  },
};
