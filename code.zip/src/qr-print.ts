export type PrintableQr = {
  rowNumber: number;
  title: string;
  content: string;
  dataUrl?: string;
  productName?: string;
  quantity?: string;
  status?: string;
};

export const QR_CODES_PER_PAGE = 15;
const PAGE_COLUMNS = [18, 96, 24, 52] as const;
const PAGE_ROWS = QR_CODES_PER_PAGE;
const PAGE_WIDTH_MM = 210;
const PAGE_HEIGHT_MM = 297;
const PAGE_MARGIN_LEFT_MM = 10;
const PAGE_MARGIN_RIGHT_MM = 10;
const PAGE_MARGIN_TOP_MM = 10;
const PAGE_MARGIN_BOTTOM_MM = 10;
const TABLE_HEADER_MM = 8;
const DATA_ROW_MM = 17.2;
const DOCUMENT_HEADER_MM = 10;
const TABLE_WIDTH_MM = PAGE_COLUMNS.reduce((total, width) => total + width, 0);
const COLUMN_LABELS = ['MÃ QR', 'TÊN SẢN PHẨM', 'SỐ LƯỢNG', 'TRẠNG THÁI'];

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character] ?? character);
}

function printableResults(results: PrintableQr[]): (PrintableQr & { dataUrl: string })[] {
  return results.filter((result): result is PrintableQr & { dataUrl: string } => Boolean(result.dataUrl));
}

function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(offset + chunkSize, bytes.length)));
  }
  return btoa(binary);
}

function fitLines(lines: string[], maximum: number): string[] {
  if (lines.length <= maximum) return lines;
  const fitted = lines.slice(0, maximum);
  fitted[maximum - 1] = `${fitted[maximum - 1].replace(/[.…]+$/u, '')}…`;
  return fitted;
}

function linesFor(pdf: import('jspdf').jsPDF, value: string | undefined, width: number, maximum: number): string[] {
  const normalised = (value || '—').replace(/\s+/g, ' ').trim();
  return fitLines(pdf.splitTextToSize(normalised, width), maximum);
}

export async function createA4Pdf(results: PrintableQr[], fileName: string): Promise<Blob> {
  const printable = printableResults(results);
  if (!printable.length) throw new Error('Chưa có mã QR hợp lệ để xuất PDF.');

  const [{ jsPDF }, fontResponse] = await Promise.all([
    import('jspdf'),
    fetch('/fonts/NotoSans-Regular.ttf'),
  ]);
  if (!fontResponse.ok) throw new Error('Không tải được font in tiếng Việt.');
  const fontBase64 = bufferToBase64(await fontResponse.arrayBuffer());
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
  pdf.addFileToVFS('NotoSans-Regular.ttf', fontBase64);
  pdf.addFont('NotoSans-Regular.ttf', 'NotoSans', 'normal');
  pdf.setProperties({ title: `${fileName} — bảng mã QR A4`, subject: '15 dòng mỗi trang A4, lề 10 mm bốn cạnh', creator: 'Excel QR' });

  const pageCount = Math.ceil(printable.length / PAGE_ROWS);
  const columnStarts = [PAGE_MARGIN_LEFT_MM];
  for (let index = 1; index < PAGE_COLUMNS.length; index += 1) {
    columnStarts.push(columnStarts[index - 1] + PAGE_COLUMNS[index - 1]);
  }
  const tableX = PAGE_MARGIN_LEFT_MM;
  const tableY = PAGE_MARGIN_TOP_MM + DOCUMENT_HEADER_MM;
  const bodyY = tableY + TABLE_HEADER_MM;

  for (let pageIndex = 0; pageIndex < pageCount; pageIndex += 1) {
    if (pageIndex > 0) pdf.addPage('a4', 'portrait');
    const pageRows = printable.slice(pageIndex * PAGE_ROWS, (pageIndex + 1) * PAGE_ROWS);
    const titleLines = pdf.splitTextToSize(fileName.replace(/\s+/g, ' ').trim(), 132);
    const headerTitle = fitLines(titleLines, 1)[0] || 'Danh sách sản phẩm';
    pdf.setFont('NotoSans', 'normal');
    pdf.setTextColor(24, 63, 58);
    pdf.setFontSize(9);
    pdf.text(headerTitle, PAGE_MARGIN_LEFT_MM, PAGE_MARGIN_TOP_MM + 4.2);
    pdf.setFontSize(6.2);
    pdf.setTextColor(97, 116, 106);
    pdf.text(`A4 dọc · lề 10 mm bốn cạnh · ${QR_CODES_PER_PAGE} dòng/trang`, PAGE_MARGIN_LEFT_MM, PAGE_MARGIN_TOP_MM + 8.2);
    pdf.setTextColor(24, 63, 58);
    pdf.text(`Trang ${pageIndex + 1}/${pageCount}`, PAGE_WIDTH_MM - PAGE_MARGIN_RIGHT_MM, PAGE_MARGIN_TOP_MM + 5, { align: 'right' });

    pdf.setFillColor(24, 63, 58);
    pdf.setDrawColor(24, 63, 58);
    pdf.rect(tableX, tableY, TABLE_WIDTH_MM, TABLE_HEADER_MM, 'F');
    pdf.setFontSize(7);
    pdf.setTextColor(255, 255, 255);
    COLUMN_LABELS.forEach((label, columnIndex) => {
      const start = columnStarts[columnIndex];
      const width = PAGE_COLUMNS[columnIndex];
      pdf.text(label, columnIndex === 0 ? start + width / 2 : start + 2, tableY + 5.2, columnIndex === 0 ? { align: 'center' } : undefined);
    });
    pdf.setDrawColor(255, 255, 255);
    columnStarts.slice(1).forEach((x) => pdf.line(x, tableY, x, tableY + TABLE_HEADER_MM));

    pageRows.forEach((result, localIndex) => {
      const y = bodyY + localIndex * DATA_ROW_MM;
      if (localIndex % 2 === 1) {
        pdf.setFillColor(247, 248, 244);
        pdf.rect(tableX, y, TABLE_WIDTH_MM, DATA_ROW_MM, 'F');
      }
      pdf.setDrawColor(211, 219, 211);
      pdf.setLineWidth(0.16);
      pdf.rect(tableX, y, TABLE_WIDTH_MM, DATA_ROW_MM);
      columnStarts.slice(1).forEach((x) => pdf.line(x, y, x, y + DATA_ROW_MM));

      const qrSize = 15;
      const qrX = columnStarts[0] + (PAGE_COLUMNS[0] - qrSize) / 2;
      pdf.addImage(result.dataUrl, 'PNG', qrX, y + (DATA_ROW_MM - qrSize) / 2, qrSize, qrSize, undefined, 'FAST');

      pdf.setFont('NotoSans', 'normal');
      pdf.setTextColor(37, 52, 45);
      pdf.setFontSize(7.4);
      pdf.text(linesFor(pdf, result.productName || result.title, PAGE_COLUMNS[1] - 4, 3), columnStarts[1] + 2, y + 3.3);
      pdf.setTextColor(45, 83, 70);
      pdf.text(linesFor(pdf, result.quantity, PAGE_COLUMNS[2] - 4, 1), columnStarts[2] + 2, y + 7.8);
      pdf.setTextColor(74, 91, 81);
      pdf.text(linesFor(pdf, result.status, PAGE_COLUMNS[3] - 4, 2), columnStarts[3] + 2, y + 3.3);
    });
  }

  const usableWidth = PAGE_WIDTH_MM - PAGE_MARGIN_LEFT_MM - PAGE_MARGIN_RIGHT_MM;
  const usableHeight = PAGE_HEIGHT_MM - PAGE_MARGIN_TOP_MM - PAGE_MARGIN_BOTTOM_MM;
  const usedHeight = DOCUMENT_HEADER_MM + TABLE_HEADER_MM + PAGE_ROWS * DATA_ROW_MM;
  if (TABLE_WIDTH_MM > usableWidth) throw new Error('Bảng vượt quá vùng in ngang A4.');
  if (usedHeight > usableHeight) throw new Error('Bố cục 15 dòng vượt quá vùng in A4.');
  return pdf.output('blob');
}

export function buildPrintDocument(results: PrintableQr[], fileName: string): string {
  const printable = printableResults(results);
  const pageCount = Math.ceil(printable.length / PAGE_ROWS);
  const pages = Array.from({ length: pageCount }, (_, pageIndex) => {
    const pageItems = printable.slice(pageIndex * PAGE_ROWS, (pageIndex + 1) * PAGE_ROWS);
    const rows = pageItems.map((result) => `
      <tr>
        <td class="qr-cell"><img src="${result.dataUrl}" alt="Mã QR" /></td>
        <td class="product-cell">${escapeHtml(result.productName || result.title || '—')}</td>
        <td class="quantity-cell">${escapeHtml(result.quantity || '—')}</td>
        <td class="status-cell">${escapeHtml(result.status || '—')}</td>
      </tr>`).join('');
    return `
      <section class="print-page" aria-label="Trang ${pageIndex + 1} trên ${pageCount}">
        <header class="print-page-header"><div class="print-file-title">${escapeHtml(fileName || 'Danh sách sản phẩm')}</div><div class="print-header-meta">A4 dọc · lề 10 mm bốn cạnh · ${QR_CODES_PER_PAGE} dòng/trang</div><span class="print-page-number">Trang ${pageIndex + 1}/${pageCount}</span></header>
        <table class="product-table"><colgroup><col style="width:18mm"><col style="width:96mm"><col style="width:24mm"><col style="width:52mm"></colgroup><thead><tr><th>MÃ QR</th><th>TÊN SẢN PHẨM</th><th>SỐ LƯỢNG</th><th>TRẠNG THÁI</th></tr></thead><tbody>${rows}</tbody></table>
      </section>`;
  }).join('');

  return `<!doctype html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(fileName)} — danh sách QR A4</title>
  <style>
    @font-face { font-family: NotoLocal; src: url('/fonts/NotoSans-Regular.ttf') format('truetype'); font-weight: 400; }
    @page { size: A4 portrait; margin: 10mm 10mm 10mm 10mm; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; font-family: NotoLocal, Arial, sans-serif; color: #183f3a; }
    .print-page { width: 190mm; height: 277mm; overflow: hidden; break-after: page; page-break-after: always; background: #fff; }
    .print-page:last-child { break-after: auto; page-break-after: auto; }
    .print-page-header { height: 10mm; position: relative; display: flex; flex-direction: column; justify-content: center; overflow: hidden; }
    .print-file-title { max-width: 145mm; overflow: hidden; color: #183f3a; font-size: 9pt; font-weight: 700; line-height: 1.15; text-overflow: ellipsis; white-space: nowrap; }
    .print-header-meta { margin-top: .6mm; color: #61746a; font-size: 6.2pt; }
    .print-page-number { position: absolute; top: 2mm; right: 0; color: #183f3a; font-size: 6.2pt; }
    .product-table { width: 190mm; table-layout: fixed; border-collapse: collapse; }
    .product-table thead tr { height: 8mm; }
    .product-table th { padding: .5mm 1.2mm; border: .2mm solid #183f3a; color: #fff; background: #183f3a; font-size: 7pt; font-weight: 700; text-align: left; vertical-align: middle; }
    .product-table th:first-child { text-align: center; }
    .product-table tbody tr { height: 17.2mm; break-inside: avoid; page-break-inside: avoid; }
    .product-table td { height: 17.2mm; padding: .5mm 1.2mm; overflow: hidden; border: .2mm solid #d3dbd3; color: #25342d; font-size: 7.5pt; line-height: 1.15; vertical-align: middle; }
    .product-table tbody tr:nth-child(even) td { background: #f7f8f4; }
    .product-table td.qr-cell { padding: 0; text-align: center; }
    .product-table td.qr-cell img { width: 15mm; height: 15mm; display: inline-block; image-rendering: pixelated; vertical-align: middle; }
    .product-table td.product-cell, .product-table td.status-cell { overflow-wrap: anywhere; }
    .product-table td.quantity-cell { color: #2d5346; text-align: center; }
    @media screen {
      body { padding: 8mm 0; background: #e9ece7; }
      .print-page { margin: 0 auto 8mm; box-shadow: 0 2mm 8mm #0002; }
    }
    @media print {
      html, body { width: 190mm; margin: 0; padding: 0; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .print-page { margin: 0; box-shadow: none; }
    }
  </style>
</head>
<body>
  ${pages}
  <script>
    window.addEventListener('load', async () => {
      try { await document.fonts.ready; } catch {}
      await Promise.all(Array.from(document.images).map((image) => image.decode().catch(() => {})));
      window.setTimeout(() => { window.focus(); window.print(); }, 250);
    });
    window.addEventListener('afterprint', () => window.close());
  </script>
</body>
</html>`;
}
