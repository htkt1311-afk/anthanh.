import { useMemo, useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import { ArrowDownToLine, ArrowRight, BadgeCheck, Check, ChevronDown, CircleAlert, CloudOff, Download, FileDown, FileSpreadsheet, FileUp, LockKeyhole, LogOut, Printer, QrCode, RefreshCw, ShieldCheck, Sparkles, Table2, X } from 'lucide-react';
import { buildPrintDocument, createA4Pdf, QR_CODES_PER_PAGE } from './qr-print';
import './styles.css';
import { AdminDashboard } from './auth/AdminDashboard';
import { AccountStatusScreen, AuthConnectionScreen, AuthLoadingScreen, AuthPortal } from './auth/AuthScreens';
import { useAuthSession } from './auth/useAuthSession';

type Column = { key: string; label: string };
type SheetData = { name: string; columns: Column[]; rows: string[][] };
type QrResult = { rowNumber: number; title: string; content: string; rowData: string[]; dataUrl?: string; error?: string };
type PrintFieldMap = { productName: string; quantity: string; status: string };

const PRINT_FIELDS: { key: keyof PrintFieldMap; label: string }[] = [
  { key: 'productName', label: 'Tên sản phẩm' },
  { key: 'quantity', label: 'Số lượng' },
  { key: 'status', label: 'Trạng thái' },
];

const SEPARATORS = [
  { label: 'Dấu chấm giữa', value: ' · ' },
  { label: 'Gạch ngang', value: ' — ' },
  { label: 'Dấu phẩy', value: ', ' },
  { label: 'Xuống dòng', value: '\n' },
  { label: 'Không có', value: '' },
];

function normaliseCell(value: unknown): string {
  return value === null || value === undefined ? '' : String(value).trim();
}

function normaliseHeader(value: string): string {
  return value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/[^a-z0-9]+/g, ' ').trim();
}

function detectPrintFields(columns: Column[], fallbackName = ''): PrintFieldMap {
  const headers = columns.map((column) => ({ key: column.key, value: normaliseHeader(column.label) }));
  const find = (aliases: string[]) => {
    const exact = headers.find((header) => aliases.includes(header.value));
    return exact?.key ?? headers.find((header) => aliases.some((alias) => header.value.includes(alias)))?.key ?? '';
  };
  return {
    productName: find(['ten san pham', 'san pham', 'ten hang', 'mat hang', 'product name', 'item name', 'product']) || fallbackName || columns[0]?.key || '',
    quantity: find(['so luong', 'quantity', 'total quantity', 'qty', 'sl']),
    status: find(['trang thai', 'tinh trang', 'order status', 'status']),
  };
}

async function parseWorkbook(buffer: ArrayBuffer): Promise<SheetData[]> {
  const XLSX = await import('xlsx');
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
  if (!workbook.SheetNames.length) throw new Error('Không tìm thấy trang tính nào trong tệp này.');

  return workbook.SheetNames.map((name) => {
    const worksheet = workbook.Sheets[name];
    const source = XLSX.utils.sheet_to_json(worksheet, {
      header: 1,
      raw: false,
      defval: '',
      blankrows: false,
    }) as unknown[][];
    const nonEmptyRows = source.filter((row) => Array.isArray(row) && row.some((cell) => normaliseCell(cell) !== ''));
    if (!nonEmptyRows.length) return { name, columns: [], rows: [] };

    const seen = new Map<string, number>();
    const columns = nonEmptyRows[0].map((cell, index) => {
      const base = normaliseCell(cell) || `Cột ${index + 1}`;
      const count = (seen.get(base) ?? 0) + 1;
      seen.set(base, count);
      return { key: `column-${index}`, label: count === 1 ? base : `${base} (${count})` };
    });
    const rows = nonEmptyRows.slice(1).map((row) => columns.map((_, index) => normaliseCell(row[index])));
    return { name, columns, rows };
  });
}

function safeName(value: string): string {
  const ascii = value.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  return ascii.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 48) || 'ma_qr';
}

function saveDataUrl(dataUrl: string, filename: string) {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function App() {
  const auth = useAuthSession();
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState('');
  const [sheets, setSheets] = useState<SheetData[]>([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [printFields, setPrintFields] = useState<PrintFieldMap>({ productName: '', quantity: '', status: '' });
  const [statusFilter, setStatusFilter] = useState('');
  const [separator, setSeparator] = useState(SEPARATORS[0].value);
  const [includeLabels, setIncludeLabels] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<QrResult[] | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const activeSheet = sheets[activeSheetIndex];
  const rows = activeSheet?.rows ?? [];
  const columns = activeSheet?.columns ?? [];
  const successfulResults = results?.filter((result) => result.dataUrl) ?? [];
  const failedResults = results?.filter((result) => result.error) ?? [];
  const statusOptions = useMemo(() => {
    const statusIndex = columns.findIndex((column) => column.key === printFields.status);
    if (statusIndex < 0) return [];
    const counts = new Map<string, number>();
    rows.forEach((row) => {
      const status = normaliseCell(row[statusIndex]) || '—';
      counts.set(status, (counts.get(status) ?? 0) + 1);
    });
    return [...counts.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((first, second) => first.value.localeCompare(second.value, 'vi'));
  }, [columns, printFields.status, rows]);
  const filteredSuccessfulResults = successfulResults.filter((result) => {
    if (!statusFilter) return true;
    const statusIndex = columns.findIndex((column) => column.key === printFields.status);
    const value = statusIndex >= 0 ? normaliseCell(result.rowData[statusIndex]) || '—' : '—';
    return value === statusFilter;
  });
  const printResults = filteredSuccessfulResults.map((result) => {
    const mappedValue = (key: string) => {
      const columnIndex = columns.findIndex((column) => column.key === key);
      return columnIndex >= 0 ? result.rowData[columnIndex]?.trim() || '—' : '—';
    };
    return {
      ...result,
      productName: mappedValue(printFields.productName),
      quantity: mappedValue(printFields.quantity),
      status: mappedValue(printFields.status),
    };
  });
  const step = results ? 3 : sheets.length ? 2 : 1;

  const firstContentPreview = useMemo(() => {
    if (!rows.length || !selectedColumns.length) return '';
    const parts = selectedColumns
      .map((key) => {
        const index = columns.findIndex((column) => column.key === key);
        if (index < 0) return '';
        const value = rows[0]?.[index] ?? '';
        if (!value) return '';
        return includeLabels ? `${columns[index].label}: ${value}` : value;
      })
      .filter(Boolean);
    return parts.join(separator);
  }, [columns, includeLabels, rows, selectedColumns, separator]);

  async function loadFile(file?: File) {
    if (!file) return;
    setError('');
    setNotice('');
    setResults(null);
    setProgress(0);
    setStatusFilter('');
    const extensionOkay = /\.(xlsx|xls)$/i.test(file.name);
    if (!extensionOkay) {
      setError('Vui lòng chọn tệp Excel có định dạng .xlsx hoặc .xls.');
      return;
    }
    if (file.size === 0) {
      setError('Tệp này đang trống. Hãy chọn một file Excel có dữ liệu nhé.');
      return;
    }

    setIsReading(true);
    try {
      const parsed = await parseWorkbook(await file.arrayBuffer());
      if (!parsed.some((sheet) => sheet.columns.length > 0)) {
        throw new Error('Không tìm thấy dữ liệu trong tệp Excel. Hãy kiểm tra lại hàng tiêu đề.');
      }
      setFileName(file.name);
      setSheets(parsed);
      const firstUsable = parsed.findIndex((sheet) => sheet.columns.length > 0);
      setActiveSheetIndex(firstUsable >= 0 ? firstUsable : 0);
      setSelectedColumns(parsed[firstUsable]?.columns[0] ? [parsed[firstUsable].columns[0].key] : []);
      const initialColumns = parsed[firstUsable]?.columns ?? [];
      setPrintFields(detectPrintFields(initialColumns, initialColumns[0]?.key));
      setNotice('Đã đọc file ngay trên trình duyệt. Dữ liệu không được tải lên máy chủ.');
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : 'Không thể đọc tệp Excel này.';
      setError(message.includes('Unsupported') || message.includes('File is not') ? 'Tệp Excel không hợp lệ hoặc bị hỏng. Hãy thử lưu lại dưới dạng .xlsx rồi tải lên.' : message);
      setSheets([]);
      setFileName('');
      setPrintFields({ productName: '', quantity: '', status: '' });
    } finally {
      setIsReading(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  }

  function onFileChange(event: ChangeEvent<HTMLInputElement>) {
    void loadFile(event.target.files?.[0]);
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setIsDragging(false);
    void loadFile(event.dataTransfer.files?.[0]);
  }

  function changeSheet(index: number) {
    setActiveSheetIndex(index);
    setSelectedColumns(sheets[index]?.columns[0] ? [sheets[index].columns[0].key] : []);
    const nextColumns = sheets[index]?.columns ?? [];
    setPrintFields(detectPrintFields(nextColumns, nextColumns[0]?.key));
    setStatusFilter('');
    setResults(null);
    setError('');
    setNotice('');
  }

  function toggleColumn(key: string) {
    setSelectedColumns((current) => current.includes(key) ? current.filter((item) => item !== key) : [...current, key]);
    setResults(null);
  }

  async function generateQrs() {
    if (!activeSheet || !selectedColumns.length) {
      setError('Hãy chọn ít nhất một cột để tạo mã QR.');
      return;
    }
    if (!rows.length) {
      setError('Trang tính này chưa có bản ghi bên dưới hàng tiêu đề.');
      return;
    }
    setError('');
    setNotice('');
    setIsGenerating(true);
    setProgress(0);
    const generated: QrResult[] = [];
    const QRCode = (await import('qrcode')).default;

    for (let rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
      const row = rows[rowIndex];
      const parts = selectedColumns.map((key) => {
        const columnIndex = columns.findIndex((column) => column.key === key);
        const value = columnIndex >= 0 ? row[columnIndex] ?? '' : '';
        return value && includeLabels && columnIndex >= 0 ? `${columns[columnIndex].label}: ${value}` : value;
      }).filter(Boolean);
      const content = parts.join(separator);
      const title = selectedColumns
        .map((key) => {
          const columnIndex = columns.findIndex((column) => column.key === key);
          return columnIndex >= 0 ? row[columnIndex] : '';
        })
        .find((value) => value?.trim()) || `Bản ghi ${rowIndex + 1}`;

      if (!content.trim()) {
        generated.push({ rowNumber: rowIndex + 1, title, content, rowData: [...row], error: 'Các cột đã chọn không có dữ liệu ở dòng này.' });
      } else {
        try {
          const dataUrl = await QRCode.toDataURL(content, {
            errorCorrectionLevel: 'M',
            margin: 2,
            width: 1024,
            color: { dark: '#183f3a', light: '#ffffff' },
          });
          generated.push({ rowNumber: rowIndex + 1, title, content, rowData: [...row], dataUrl });
        } catch {
          generated.push({ rowNumber: rowIndex + 1, title, content, rowData: [...row], error: 'Nội dung quá dài để mã hóa thành QR.' });
        }
      }

      if ((rowIndex + 1) % 8 === 0 || rowIndex === rows.length - 1) {
        setProgress(Math.round(((rowIndex + 1) / rows.length) * 100));
        await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
      }
    }

    setResults(generated);
    setIsGenerating(false);
    setNotice(`Đã tạo ${generated.filter((result) => result.dataUrl).length} mã QR từ ${rows.length} bản ghi.`);
  }

  async function downloadZip() {
    if (!printResults.length) return;
    setIsZipping(true);
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      const folder = zip.folder('ma-qr-excel');
      printResults.forEach((result) => {
        const base64 = result.dataUrl?.split(',')[1];
        if (!base64) return;
        folder?.file(`QR_dong_${String(result.rowNumber).padStart(3, '0')}_${safeName(result.title)}.png`, base64, { base64: true });
      });
      const csvRows = [
        ['Dòng Excel', 'Tên', 'Nội dung mã hóa'].map((cell) => `"${cell.replace(/"/g, '""')}"`).join(','),
        ...printResults.map((result) => [String(result.rowNumber + 1), result.title, result.content]
          .map((cell) => `"${cell.replace(/"/g, '""')}"`).join(',')),
      ];
      folder?.file('danh-sach-ma-qr.csv', `\uFEFF${csvRows.join('\r\n')}`);
      const pdf = await createA4Pdf(printResults, fileName);
      folder?.file(`${safeName(fileName.replace(/\.(xlsx|xls)$/i, ''))}_QR_A4_15-ma-moi-trang.pdf`, pdf);
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${safeName(fileName.replace(/\.(xlsx|xls)$/i, ''))}_ma_qr.zip`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch {
      setError('Chưa thể tạo tệp ZIP. Hãy thử tải từng mã QR riêng lẻ.');
    } finally {
      setIsZipping(false);
    }
  }

  async function downloadA4Pdf() {
    if (!printResults.length) return;
    setError('');
    setIsPdfGenerating(true);
    try {
      const pdf = await createA4Pdf(printResults, fileName);
      const url = URL.createObjectURL(pdf);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${safeName(fileName.replace(/\.(xlsx|xls)$/i, ''))}_QR_A4_15-ma-moi-trang.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    } catch {
      setError('Chưa thể tạo PDF A4. Hãy thử tải lại mã QR hoặc dùng nút in trực tiếp.');
    } finally {
      setIsPdfGenerating(false);
    }
  }

  function printQrSheets() {
    if (!printResults.length) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      setError('Trình duyệt đã chặn cửa sổ in. Hãy cho phép cửa sổ bật lên rồi thử lại.');
      return;
    }
    printWindow.document.open();
    printWindow.document.write(buildPrintDocument(printResults, fileName));
    printWindow.document.close();
  }

  function clearFile() {
    setFileName('');
    setSheets([]);
    setActiveSheetIndex(0);
    setSelectedColumns([]);
    setPrintFields({ productName: '', quantity: '', status: '' });
    setStatusFilter('');
    setResults(null);
    setProgress(0);
    setError('');
    setNotice('');
  }

  if (auth.loading) return <AuthLoadingScreen />;
  if (auth.connectionError && !auth.user) return <AuthConnectionScreen message={auth.connectionError} onRetry={() => auth.refresh(true)} />;
  if (!auth.user) return <AuthPortal onLogin={auth.login} actionError={auth.actionError} clearError={() => auth.setActionError('')} />;
  if (auth.user.status !== 'approved') return <AccountStatusScreen user={auth.user} onLogout={auth.logout} onRefresh={() => auth.refresh(false)} actionError={auth.actionError} />;
  if (auth.user.role === 'admin' && showAdminPanel) return <AdminDashboard admin={auth.user} onExit={() => setShowAdminPanel(false)} onLogout={auth.logout} actionError={auth.actionError} />;

  return (
    <div className="site-shell">
      <header className="topbar page-wrap">
        <a className="brand" href="#top" aria-label="Excel QR — về đầu trang">
          <span className="brand-mark" aria-hidden="true">
            <FileSpreadsheet size={23} strokeWidth={2.3} />
            <span className="brand-qr"><QrCode size={13} strokeWidth={2.7} /></span>
          </span>
          <span className="brand-copy"><strong>excel<span>qr</span></strong><small>mã hóa gọn gàng</small></span>
        </a>
        <div className="topbar-right">
          <span className="privacy-pill"><span className="privacy-dot" /> Xử lý ngay trên thiết bị</span>
          <div className="account-actions">
            <span className="account-identity" title={auth.user.username}><ShieldCheck size={13} />{auth.user.displayName || auth.user.username}</span>
            {auth.user.role === 'admin' && <button className="account-button" type="button" onClick={() => setShowAdminPanel(true)}><BadgeCheck size={14} />Quản trị</button>}
            <button className="account-button" type="button" onClick={() => void auth.logout().catch(() => {})}><LogOut size={14} />Đăng xuất</button>
            {auth.actionError && <span className="account-error" role="alert">{auth.actionError}</span>}
          </div>
          <a className="top-link" href="#cach-dung">Cách dùng <ArrowRight size={15} /></a>
        </div>
      </header>

      <main id="top">
        <section className="hero page-wrap">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> CÔNG CỤ NHỎ, VIỆC LỚN NHẸ HƠN</div>
            <h1>Biến bảng tính<br /><em>thành mã QR.</em></h1>
            <p className="hero-description">Chọn dữ liệu trong Excel, tạo mã QR cho từng dòng và tải xuống tất cả chỉ trong vài bước.</p>
            <a className="hero-cta" href="#workspace">Bắt đầu với file Excel <ArrowRight size={17} /></a>
            <div className="hero-footnote"><LockKeyhole size={14} /> File được xử lý trong trình duyệt — không tải lên máy chủ.</div>
          </div>
          <div className="hero-note" aria-label="Quy trình tạo mã QR">
            <div className="note-topline"><span>QUY TRÌNH 03 BƯỚC</span><span className="note-star"><Sparkles size={16} /></span></div>
            <div className="mini-steps">
              <div className="mini-step"><span className="mini-step-number">01</span><div><strong>Chọn bảng tính</strong><small>.xlsx hoặc .xls</small></div><FileUp size={18} /></div>
              <div className="mini-step"><span className="mini-step-number">02</span><div><strong>Chọn trường dữ liệu</strong><small>một cột hoặc nhiều cột</small></div><Table2 size={18} /></div>
              <div className="mini-step"><span className="mini-step-number">03</span><div><strong>Tải mã QR về máy</strong><small>từng mã hoặc cả bộ ZIP</small></div><ArrowDownToLine size={18} /></div>
            </div>
            <div className="note-bottom"><ShieldCheck size={15} /><span>Riêng tư từ khâu đầu tiên</span><span className="note-scribble">✳</span></div>
          </div>
          <span className="hero-index">01<span>—</span>03</span>
        </section>

        <section className="trust-strip page-wrap" aria-label="Ưu điểm">
          <div><span className="trust-icon"><ShieldCheck size={16} /></span><span><strong>Không gửi file đi đâu</strong><small>Dữ liệu ở lại trên trình duyệt của bạn</small></span></div>
          <div><span className="trust-icon trust-icon-teal"><QrCode size={16} /></span><span><strong>Mỗi dòng một mã riêng</strong><small>Chọn đúng trường bạn muốn mã hóa</small></span></div>
          <div><span className="trust-icon trust-icon-yellow"><Download size={16} /></span><span><strong>Tải một lần, dùng mọi nơi</strong><small>PNG riêng lẻ hoặc gói ZIP tiện lợi</small></span></div>
        </section>

        <section className="workspace-section" id="workspace">
          <div className="section-heading page-wrap">
            <div><span className="section-kicker">XƯỞNG TẠO MÃ</span><h2>Bắt đầu từ bảng tính của bạn.</h2></div>
            <span className="workspace-caption"><span className="caption-stamp">✳</span> Tài khoản đã xác thực</span>
          </div>

          <div className="workspace-card">
            <div className="workspace-top">
              <div className="workspace-top-title"><span className="workspace-icon"><QrCode size={19} /></span><div><strong>Tạo mã QR từ Excel</strong><small>Thực hiện từng bước, ngay tại đây</small></div></div>
              <div className="stepper" aria-label={`Bước ${step} trên 3`}>
                {[1, 2, 3].map((number) => <div className={`stepper-item ${step === number ? 'is-current' : ''} ${step > number ? 'is-done' : ''}`} key={number}><span>{step > number ? <Check size={13} /> : `0${number}`}</span><small>{number === 1 ? 'Tải file' : number === 2 ? 'Chọn dữ liệu' : 'Tải mã QR'}</small></div>)}
              </div>
            </div>

            <div className="workspace-body">
              {!sheets.length ? (
                <div className={`dropzone ${isDragging ? 'is-dragging' : ''} ${isReading ? 'is-reading' : ''}`} onDragEnter={(event) => { event.preventDefault(); setIsDragging(true); }} onDragOver={(event) => event.preventDefault()} onDragLeave={(event) => { if (!event.currentTarget.contains(event.relatedTarget as Node)) setIsDragging(false); }} onDrop={onDrop}>
                  <input ref={inputRef} className="visually-hidden" type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={onFileChange} aria-label="Chọn file Excel" />
                  <div className="upload-illustration"><span className="upload-file-icon"><FileSpreadsheet size={26} /></span><span className="upload-plus">+</span></div>
                  <div className="dropzone-copy"><strong>{isReading ? 'Đang đọc bảng tính…' : isDragging ? 'Thả file vào đây nhé' : 'Thả file Excel vào đây'}</strong><span>hoặc <button className="text-button" type="button" onClick={() => inputRef.current?.click()} disabled={isReading}>chọn file từ thiết bị</button></span></div>
                  <div className="dropzone-bottom"><span><BadgeCheck size={15} /> Hỗ trợ .XLSX và .XLS</span><span><LockKeyhole size={14} /> Xử lý riêng tư</span></div>
                  <div className="dropzone-corner">✳</div>
                </div>
              ) : (
                <div className="data-workspace">
                  <div className="file-banner">
                    <div className="file-banner-left"><span className="file-type-icon"><FileSpreadsheet size={20} /></span><span className="file-info"><strong title={fileName}>{fileName}</strong><small>{rows.length.toLocaleString('vi-VN')} bản ghi · {columns.length} cột · {sheets.length} {sheets.length === 1 ? 'sheet' : 'sheet'}</small></span></div>
                    <div className="file-actions"><button className="quiet-button" type="button" onClick={() => inputRef.current?.click()}><RefreshCw size={14} /> Đổi file</button><button className="icon-button" type="button" onClick={clearFile} aria-label="Gỡ file"><X size={17} /></button><input ref={inputRef} className="visually-hidden" type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={onFileChange} /></div>
                  </div>

                  <div className="sheet-row">
                    <label htmlFor="sheet-select"><span className="label-overline">TRANG TÍNH</span><span className="select-wrap"><Table2 size={16} /><select id="sheet-select" value={activeSheetIndex} onChange={(event) => changeSheet(Number(event.target.value))}>{sheets.map((sheet, index) => <option value={index} key={`${sheet.name}-${index}`}>{sheet.name}</option>)}</select><ChevronDown size={15} /></span></label>
                    <div className="sheet-summary"><span className="status-dot" />Đã đọc thành công</div>
                  </div>

                  {columns.length && rows.length ? <>
                    <div className="preview-heading"><div><span className="label-overline">XEM TRƯỚC DỮ LIỆU</span><span className="preview-caption">Hiển thị tối đa 6 dòng đầu tiên</span></div><span className="record-count"><span>{rows.length.toLocaleString('vi-VN')}</span> dòng</span></div>
                    <div className="table-scroll"><table className="data-table"><thead><tr><th className="row-number">#</th>{columns.map((column) => <th key={column.key} title={column.label}>{column.label}</th>)}</tr></thead><tbody>{rows.slice(0, 6).map((row, rowIndex) => <tr key={rowIndex}><td className="row-number">{String(rowIndex + 1).padStart(2, '0')}</td>{columns.map((column, columnIndex) => <td key={column.key} title={row[columnIndex]}>{row[columnIndex] || <span className="empty-cell">—</span>}</td>)}</tr>)}</tbody></table></div>

                    <div className="selection-area">
                      <div className="selection-heading"><div><span className="label-overline">NỘI DUNG MÃ QR</span><strong>Chọn trường cần đưa vào mã</strong></div><span className="selection-hint">Có thể chọn nhiều cột</span></div>
                      <div className="field-list">{columns.map((column) => <label className={`field-chip ${selectedColumns.includes(column.key) ? 'is-selected' : ''}`} key={column.key}><input type="checkbox" checked={selectedColumns.includes(column.key)} onChange={() => toggleColumn(column.key)} /><span className="custom-check">{selectedColumns.includes(column.key) && <Check size={12} />}</span><span className="field-chip-label">{column.label}</span></label>)}</div>
                      <div className="print-mapping">
                        <div className="print-mapping-head"><strong>Các cột hiển thị trên bản in</strong><span>Tự nhận diện theo tên tiêu đề — bạn có thể đổi lại.</span></div>
                        <div className="print-mapping-grid">{PRINT_FIELDS.map(({ key, label }) => <label className="print-map-field" key={key}><span>{label}</span><span className="print-map-select"><select value={printFields[key]} onChange={(event) => { setPrintFields((current) => ({ ...current, [key]: event.target.value })); if (key === 'status') setStatusFilter(''); }}><option value="">Không chọn</option>{columns.map((column) => <option value={column.key} key={column.key}>{column.label}</option>)}</select><ChevronDown size={13} /></span></label>)}</div>
                        <div className="status-export-filter"><label className="status-export-label" htmlFor="status-export-list"><strong>Trạng thái cần xuất</strong><small>Chọn một giá trị hoặc xuất tất cả trạng thái.</small></label><select id="status-export-list" className="status-export-list" size={Math.min(Math.max(statusOptions.length + 1, 2), 5)} value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="">Tất cả trạng thái</option>{statusOptions.map(({ value, count }) => <option value={value} key={value}>{value} ({count})</option>)}</select></div>
                      </div>
                      <div className="format-row"><label className="format-control"><span>Ngăn cách nội dung</span><span className="format-select-wrap"><select value={separator} onChange={(event) => { setSeparator(event.target.value); setResults(null); }}>{SEPARATORS.map((item) => <option value={item.value} key={item.label}>{item.label}</option>)}</select><ChevronDown size={13} /></span></label><label className="toggle-control"><input type="checkbox" checked={includeLabels} onChange={(event) => { setIncludeLabels(event.target.checked); setResults(null); }} /><span className="toggle-track"><span /></span><span>Thêm tên cột</span></label></div>
                      <div className="content-preview"><span className="preview-qr"><QrCode size={16} /></span><div><small>NỘI DUNG SẼ ĐƯỢC MÃ HÓA · DÒNG ĐẦU</small><p>{firstContentPreview || 'Chọn ít nhất một cột có dữ liệu để xem trước.'}</p></div></div>
                    </div>
                    <div className="create-row"><div className="privacy-inline"><CloudOff size={15} /><span>Excel của bạn không rời khỏi thiết bị này.</span></div><button className="primary-button" type="button" onClick={() => void generateQrs()} disabled={isGenerating || selectedColumns.length === 0}><QrCode size={17} />{isGenerating ? 'Đang tạo mã…' : results ? 'Tạo lại mã QR' : 'Tạo mã QR'}<ArrowRight size={16} /></button></div>
                    {isGenerating && <div className="progress-wrap" aria-live="polite"><div className="progress-label"><span>Đang tạo mã QR cho từng dòng</span><strong>{progress}%</strong></div><div className="progress-track"><span style={{ width: `${progress}%` }} /></div></div>}
                  </> : <div className="empty-sheet"><Table2 size={22} /><strong>Sheet này chưa có dữ liệu để xem.</strong><span>Hãy chọn một trang tính khác trong file.</span></div>}
                </div>
              )}

              {error && <div className="message message-error" role="alert"><CircleAlert size={17} /><span>{error}</span><button type="button" onClick={() => setError('')} aria-label="Đóng thông báo"><X size={15} /></button></div>}
              {notice && !error && <div className="message message-success" role="status"><BadgeCheck size={17} /><span>{notice}</span></div>}

              {results && <section className="results-section" aria-live="polite">
                <div className="results-heading"><div><span className="label-overline">KẾT QUẢ CỦA BẠN</span><h3>Bảng mã QR sản phẩm.</h3><p>{printResults.length} mã sẽ xuất{statusFilter ? ` · trạng thái: ${statusFilter}` : ''}{failedResults.length ? ` · ${failedResults.length} dòng lỗi` : ''}</p><span className="page-layout-note">A4 dọc · lề 10 mm bốn cạnh · {QR_CODES_PER_PAGE} dòng/trang · QR / tên sản phẩm / số lượng / trạng thái</span></div><div className="results-actions"><button className="print-button" type="button" onClick={printQrSheets} disabled={!printResults.length}><Printer size={15} />In trực tiếp</button><button className="pdf-button" type="button" onClick={() => void downloadA4Pdf()} disabled={!printResults.length || isPdfGenerating}><FileDown size={15} />{isPdfGenerating ? 'Đang tạo PDF…' : 'Tải PDF A4'}</button><button className="zip-button" type="button" onClick={() => void downloadZip()} disabled={!printResults.length || isZipping || isPdfGenerating}><Download size={15} />{isZipping ? 'Đang đóng gói…' : 'Tải tất cả (.ZIP)'}</button></div></div>
                {failedResults.length > 0 && <div className="result-warning"><CircleAlert size={15} /><span>{failedResults.length} dòng bị bỏ qua — kiểm tra nội dung đã chọn. Mã hợp lệ vẫn có thể tải xuống.</span></div>}
                <div className="results-grid">{results.map((result) => <article className={`qr-card ${result.error ? 'qr-card-error' : ''}`} key={result.rowNumber}>
                  <div className="qr-card-top"><span className="qr-row-number">DÒNG {String(result.rowNumber + 1).padStart(2, '0')}</span>{result.dataUrl ? <span className="qr-ready"><Check size={12} /> SẴN SÀNG</span> : <span className="qr-error-tag">BỎ QUA</span>}</div>
                  {result.dataUrl ? <><div className="qr-image-wrap"><img src={result.dataUrl} alt={`Mã QR cho ${result.title}`} loading="lazy" /></div><strong className="qr-card-title" title={result.title}>{result.title}</strong><p className="qr-card-content">{result.content}</p><button className="download-single" type="button" onClick={() => saveDataUrl(result.dataUrl!, `QR_dong_${String(result.rowNumber + 1).padStart(3, '0')}_${safeName(result.title)}.png`)}><ArrowDownToLine size={15} /> Tải PNG</button></> : <div className="qr-card-error-body"><CircleAlert size={23} /><strong>{result.title}</strong><p>{result.error}</p></div>}
                </article>)}</div>
              </section>}
            </div>
            <div className="workspace-footer"><span><span className="footer-stamp">✳</span> Làm xong rồi? Các mã QR PNG luôn sẵn sàng để in hoặc chia sẻ.</span><a href="#cach-dung">Xem mẹo sử dụng <ArrowRight size={13} /></a></div>
          </div>
        </section>

        <section className="how-section page-wrap" id="cach-dung">
          <div className="how-intro"><span className="section-kicker">NHẸ NHÀNG NHƯ BA THAO TÁC</span><h2>Từ file đến QR,<br /><em>không bước thừa.</em></h2><p>Không cài đặt phần mềm, không gửi dữ liệu ra ngoài. Mọi thứ bạn cần đều nằm ngay trên trang này.</p></div>
          <div className="how-list">
            <div className="how-item"><span className="how-number">01</span><div><strong>Thả file Excel vào.</strong><p>Chọn file .xlsx hoặc .xls — chúng mình đọc ngay trong trình duyệt.</p></div><FileUp size={19} /></div>
            <div className="how-item"><span className="how-number">02</span><div><strong>Chọn sheet và cột.</strong><p>Xem trước dữ liệu rồi ghép một hoặc nhiều trường thành nội dung QR.</p></div><Table2 size={19} /></div>
            <div className="how-item"><span className="how-number">03</span><div><strong>Tạo mã, tải về.</strong><p>Tải PNG cho từng dòng hoặc đóng gói cả bộ mã thành ZIP.</p></div><Download size={19} /></div>
          </div>
        </section>

        <section className="privacy-note page-wrap">
          <div className="privacy-note-icon"><LockKeyhole size={20} /></div>
          <div><strong>File của bạn là của bạn.</strong><p>Excel QR không gửi tệp hay dữ liệu bảng tính lên máy chủ. Tệp chỉ được đọc tạm thời trong bộ nhớ của trình duyệt và không được lưu lại.</p></div>
          <ShieldCheck className="privacy-seal" size={30} />
        </section>
      </main>

      <footer className="footer page-wrap"><a className="footer-brand" href="#top"><span className="footer-mark"><QrCode size={17} /></span> excel<span>qr</span></a><span>Một công cụ nhỏ, làm việc gọn gàng. <span className="footer-heart">✳</span></span><span className="footer-privacy"><LockKeyhole size={13} /> Riêng tư từ đầu</span></footer>
    </div>
  );
}

export default App;
