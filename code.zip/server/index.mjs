import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import express from 'express';
import { initializeDatabase, pool } from './db.mjs';
import { hashPassword, verifyPassword } from './passwords.mjs';
const app = express();
const PORT = Number(process.env.API_PORT || process.env.PORT || 3000);
const SESSION_COOKIE = 'excelqr_session';
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;
const CSRF_TTL_MS = 60 * 60 * 1000;
let csrfSecret;

class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function asyncHandler(handler) {
  return (request, response, next) => Promise.resolve(handler(request, response, next)).catch(next);
}

function hashToken(value) {
  return createHash('sha256').update(value).digest('hex');
}

function publicUser(row) {
  return {
    id: row.id,
    username: row.username,
    displayName: row.displayName ?? '',
    role: row.role,
    status: row.status,
    rejectionReason: row.rejectionReason ?? null,
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt),
  };
}

function issueCsrfToken() {
  const expiry = Date.now() + CSRF_TTL_MS;
  const nonce = randomBytes(18).toString('base64url');
  const payload = `${expiry}.${nonce}`;
  const signature = createHmac('sha256', csrfSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function validCsrfToken(token) {
  if (typeof token !== 'string' || token.length > 256) return false;
  const [expiryText, nonce, signatureText, extra] = token.split('.');
  if (!expiryText || !nonce || !signatureText || extra !== undefined) return false;
  const expiry = Number(expiryText);
  if (!Number.isSafeInteger(expiry) || expiry < Date.now() || expiry > Date.now() + CSRF_TTL_MS + 60_000) return false;
  const expected = createHmac('sha256', csrfSecret).update(`${expiryText}.${nonce}`).digest();
  let supplied;
  try { supplied = Buffer.from(signatureText, 'base64url'); } catch { return false; }
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

function requireCsrf(request, response, next) {
  if (!request.is('application/json') || !validCsrfToken(request.get('X-ExcelQR-CSRF'))) {
    return response.status(403).json({ code: 'CSRF_INVALID', error: 'Phiên bảo mật đã hết hạn. Hãy thử lại.' });
  }
  next();
}

function parseCookie(header, name) {
  if (!header) return '';
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0 || part.slice(0, separator).trim() !== name) continue;
    try { return decodeURIComponent(part.slice(separator + 1).trim()); } catch { return ''; }
  }
  return '';
}

function setSessionCookie(response, token) {
  response.append('Set-Cookie', `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=${SESSION_TTL_SECONDS}`);
}

function clearSessionCookie(response) {
  response.append('Set-Cookie', `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`);
}

async function createSession(userId, executor = pool) {
  const token = randomBytes(32).toString('base64url');
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);
  await executor.execute(
    'INSERT INTO excelqr_sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)',
    [hashToken(token), userId, expiresAt],
  );
  return token;
}

async function getUserForToken(token) {
  if (!/^[A-Za-z0-9_-]{40,50}$/.test(token)) return null;
  const [rows] = await pool.execute(`
    SELECT u.id, u.username, u.display_name AS displayName, u.role, u.status,
           u.rejection_reason AS rejectionReason, u.created_at AS createdAt
    FROM excelqr_sessions s
    JOIN excelqr_users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP(3) AND u.username IS NOT NULL AND u.status = 'approved'
    LIMIT 1
  `, [hashToken(token)]);
  return rows[0] ? publicUser(rows[0]) : null;
}

function requireSession(request, response, next) {
  return asyncHandler(async () => {
    const token = parseCookie(request.headers.cookie, SESSION_COOKIE);
    if (!token) return response.status(401).json({ code: 'AUTH_REQUIRED', error: 'Vui lòng đăng nhập để tiếp tục.' });
    const user = await getUserForToken(token);
    if (!user) {
      clearSessionCookie(response);
      return response.status(401).json({ code: 'AUTH_REQUIRED', error: 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.' });
    }
    request.authUser = user;
    request.sessionTokenHash = hashToken(token);
    next();
  })(request, response, next);
}

function requireAdmin(request, response, next) {
  if (request.authUser?.role !== 'admin' || request.authUser?.status !== 'approved') {
    return response.status(403).json({ code: 'ADMIN_REQUIRED', error: 'Chỉ quản trị viên đã được xác thực mới có quyền này.' });
  }
  next();
}

app.disable('x-powered-by');
app.set('etag', false);
app.use('/api', (_request, response, next) => {
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.setHeader('Pragma', 'no-cache');
  next();
});
app.use(express.json({ limit: '32kb', strict: true }));

app.get('/_app/health', asyncHandler(async (_request, response) => {
  await pool.query('SELECT 1');
  response.status(200).json({ status: 'ok' });
}));

app.get('/api/auth/csrf', (_request, response) => {
  response.setHeader('Cache-Control', 'no-store, max-age=0');
  response.status(200).json({ csrfToken: issueCsrfToken() });
});

app.get('/api/auth/me', asyncHandler(async (request, response) => {
  const token = parseCookie(request.headers.cookie, SESSION_COOKIE);
  if (!token) return response.status(200).json({ user: null });
  const user = await getUserForToken(token);
  if (!user) clearSessionCookie(response);
  response.status(200).json({ user });
}));

app.post('/api/auth/login', requireCsrf, asyncHandler(async (request, response) => {
  const username = typeof request.body?.username === 'string' ? request.body.username.normalize('NFKC').trim() : '';
  const password = typeof request.body?.password === 'string' ? request.body.password : '';
  if (!username || Buffer.byteLength(username, 'utf8') > 100 || /[\u0000-\u001f\u007f]/u.test(username) || Buffer.byteLength(password, 'utf8') > 128) {
    throw new AppError(400, 'INVALID_CREDENTIALS', 'Tên đăng nhập hoặc mật khẩu chưa đúng định dạng.');
  }
  const [rows] = await pool.execute(
    `SELECT id, username, display_name AS displayName, password_hash AS passwordHash,
            role, status, rejection_reason AS rejectionReason, created_at AS createdAt
     FROM excelqr_users WHERE username = ? AND status = 'approved' LIMIT 1`,
    [username],
  );
  const row = rows[0];
  const passwordMatches = await verifyPassword(password || 'invalid-login-password', row?.passwordHash ?? dummyPasswordHash);
  if (!row || !passwordMatches) throw new AppError(401, 'LOGIN_FAILED', 'Tên đăng nhập hoặc mật khẩu chưa đúng.');

  const sessionToken = await createSession(row.id);
  setSessionCookie(response, sessionToken);
  response.status(200).json({ user: publicUser(row) });
}));

app.post('/api/auth/logout', requireCsrf, asyncHandler(async (request, response) => {
  const token = parseCookie(request.headers.cookie, SESSION_COOKIE);
  if (token) await pool.execute('DELETE FROM excelqr_sessions WHERE token_hash = ?', [hashToken(token)]);
  clearSessionCookie(response);
  response.status(200).json({ ok: true });
}));

app.get('/api/admin/users', requireSession, requireAdmin, asyncHandler(async (request, response) => {
  const status = typeof request.query.status === 'string' ? request.query.status : 'pending';
  const validStatuses = new Set(['pending', 'approved', 'rejected', 'all']);
  if (!validStatuses.has(status)) throw new AppError(400, 'INVALID_STATUS', 'Bộ lọc trạng thái không hợp lệ.');
  const query = `
    SELECT id, username, display_name AS displayName, role, status,
           rejection_reason AS rejectionReason, created_at AS createdAt
    FROM excelqr_users WHERE username IS NOT NULL AND role = 'user' ${status === 'all' ? '' : 'AND status = ?'}
    ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, created_at DESC
    LIMIT 500
  `;
  const [rows] = status === 'all' ? await pool.execute(query) : await pool.execute(query, [status]);
  response.status(200).json({ users: rows.map(publicUser) });
}));

app.post('/api/admin/users/:id/decision', requireCsrf, requireSession, requireAdmin, asyncHandler(async (request, response) => {
  const { id } = request.params;
  const status = request.body?.status;
  const reason = typeof request.body?.reason === 'string' ? request.body.reason.trim() : '';
  if (!/^[0-9a-f-]{36}$/i.test(id) || !['approved', 'rejected'].includes(status)) {
    throw new AppError(400, 'INVALID_DECISION', 'Thao tác xét duyệt không hợp lệ.');
  }
  if (Buffer.byteLength(reason, 'utf8') > 500) throw new AppError(400, 'REASON_TOO_LONG', 'Lý do từ chối tối đa 500 byte UTF-8.');
  const rejectionReason = status === 'rejected' ? (reason || null) : null;
  const [result] = await pool.execute(
    `UPDATE excelqr_users
     SET status = ?, rejection_reason = ?, reviewed_at = UTC_TIMESTAMP(3), reviewed_by = ?
     WHERE id = ? AND username IS NOT NULL AND role = 'user' AND status = 'pending'`,
    [status, rejectionReason, request.authUser.id, id],
  );
  if (!result.affectedRows) {
    const [currentRows] = await pool.execute('SELECT role, status FROM excelqr_users WHERE id = ? LIMIT 1', [id]);
    if (!currentRows.length || currentRows[0].role !== 'user') {
      throw new AppError(404, 'USER_NOT_FOUND', 'Không tìm thấy tài khoản thường cần xét duyệt.');
    }
    throw new AppError(409, 'USER_ALREADY_REVIEWED', 'Tài khoản đã được xử lý; hãy làm mới danh sách trước khi tiếp tục.');
  }
  const [rows] = await pool.execute(
    `SELECT id, username, display_name AS displayName, role, status,
            rejection_reason AS rejectionReason, created_at AS createdAt
     FROM excelqr_users WHERE id = ? LIMIT 1`,
    [id],
  );
  response.status(200).json({ user: publicUser(rows[0]) });
}));

app.use('/api', (_request, response) => response.status(404).json({ code: 'NOT_FOUND', error: 'Không tìm thấy API này.' }));

app.use((error, request, response, _next) => {
  const status = Number(error?.status) || (Number(error?.statusCode) === 413 ? 413 : 500);
  const code = error?.code && typeof error.code === 'string' && error.status ? error.code : 'SERVER_ERROR';
  if (status >= 500) console.error('excelqr_api_error', code);
  const message = status === 413 ? 'Dữ liệu gửi lên vượt quá giới hạn cho phép.' : error?.status ? error.message : 'Có lỗi máy chủ. Hãy thử lại sau.';
  if (!response.headersSent) response.status(status).json({ code, error: message });
});

const dummyPasswordHash = await hashPassword(randomBytes(32).toString('hex'));
const server = await (async () => {
  csrfSecret = await initializeDatabase();
  const handle = app.listen(PORT, '0.0.0.0', () => console.log(`Excel QR API listening on port ${PORT}`));
  await new Promise((resolve, reject) => {
    handle.once('listening', resolve);
    handle.once('error', reject);
  });
  return handle;
})();

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => { void pool.end().finally(() => process.exit(0)); });
    setTimeout(() => process.exit(1), 8_000).unref();
  });
}
