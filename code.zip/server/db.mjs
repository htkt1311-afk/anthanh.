import { randomBytes } from 'node:crypto';
import mysql from 'mysql2/promise';

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL is required for the Excel QR server.');

export const pool = mysql.createPool({
  uri: databaseUrl,
  waitForConnections: true,
  connectionLimit: 8,
  queueLimit: 40,
  timezone: 'Z',
});

const AUTH_SCHEMA_V1 = [
  `CREATE TABLE IF NOT EXISTS excelqr_users (
    id CHAR(36) NOT NULL PRIMARY KEY,
    email VARCHAR(254) NOT NULL,
    display_name VARCHAR(100) NOT NULL DEFAULT '',
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    rejection_reason VARCHAR(500) NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    reviewed_at DATETIME(3) NULL,
    reviewed_by CHAR(36) NULL,
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    UNIQUE KEY uq_excelqr_users_email (email),
    KEY idx_excelqr_users_status_created (status, created_at)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS excelqr_sessions (
    token_hash CHAR(64) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    expires_at DATETIME(3) NOT NULL,
    KEY idx_excelqr_sessions_user (user_id),
    KEY idx_excelqr_sessions_expiry (expires_at),
    CONSTRAINT fk_excelqr_sessions_user FOREIGN KEY (user_id)
      REFERENCES excelqr_users (id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS excelqr_settings (
    setting_key VARCHAR(80) NOT NULL PRIMARY KEY,
    setting_value TEXT NOT NULL,
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
  ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`,
];

async function columnInfo(tableName, columnName) {
  const [rows] = await pool.execute(
    `SELECT COLUMN_NAME AS columnName, IS_NULLABLE AS isNullable
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1`,
    [tableName, columnName],
  );
  return rows[0] ?? null;
}

async function indexExists(tableName, indexName) {
  const [rows] = await pool.execute(
    `SELECT INDEX_NAME AS indexName FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1`,
    [tableName, indexName],
  );
  return rows.length > 0;
}

async function applyUsernameLoginMigration() {
  const usernameColumn = await columnInfo('excelqr_users', 'username');
  if (!usernameColumn) {
    await pool.query('ALTER TABLE excelqr_users ADD COLUMN username VARCHAR(100) NULL AFTER id');
  }

  const emailColumn = await columnInfo('excelqr_users', 'email');
  if (emailColumn?.isNullable === 'NO') {
    await pool.query('ALTER TABLE excelqr_users MODIFY COLUMN email VARCHAR(254) NULL');
  }

  if (!await indexExists('excelqr_users', 'uq_excelqr_users_username')) {
    await pool.query('CREATE UNIQUE INDEX uq_excelqr_users_username ON excelqr_users (username)');
  }
}

export async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS excelqr_migrations (
      migration_id VARCHAR(100) NOT NULL PRIMARY KEY,
      applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
    ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);

  const [v1Rows] = await pool.execute(
    'SELECT migration_id FROM excelqr_migrations WHERE migration_id = ? LIMIT 1',
    ['001_auth_v1'],
  );
  if (!v1Rows.length) {
    for (const statement of AUTH_SCHEMA_V1) await pool.query(statement);
    await pool.execute('INSERT IGNORE INTO excelqr_migrations (migration_id) VALUES (?)', ['001_auth_v1']);
  }

  const [v2Rows] = await pool.execute(
    'SELECT migration_id FROM excelqr_migrations WHERE migration_id = ? LIMIT 1',
    ['002_username_login'],
  );
  if (!v2Rows.length) {
    await applyUsernameLoginMigration();
    await pool.execute('INSERT IGNORE INTO excelqr_migrations (migration_id) VALUES (?)', ['002_username_login']);
  }

  await pool.execute(
    'INSERT IGNORE INTO excelqr_settings (setting_key, setting_value) VALUES (?, ?)',
    ['admin_bootstrap_used', '0'],
  );
  await pool.execute(
    'INSERT IGNORE INTO excelqr_settings (setting_key, setting_value) VALUES (?, ?)',
    ['csrf_secret', randomBytes(32).toString('hex')],
  );

  const [rows] = await pool.execute(
    'SELECT setting_value AS settingValue FROM excelqr_settings WHERE setting_key = ? LIMIT 1',
    ['csrf_secret'],
  );
  const value = rows[0]?.settingValue;
  if (typeof value !== 'string' || !/^[a-f0-9]{64}$/i.test(value)) {
    throw new Error('CSRF signing material is unavailable.');
  }
  return Buffer.from(value, 'hex');
}
