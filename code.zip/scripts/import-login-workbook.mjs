import { randomUUID } from 'node:crypto';
import XlsxPkg from 'xlsx';
import { hashPassword } from '../server/passwords.mjs';
import { initializeDatabase, pool } from '../server/db.mjs';

const MAX_USERNAME_BYTES = 100;
const MAX_PASSWORD_BYTES = 128;
const EXPECTED_DATA_ROWS = 19;
const EXPECTED_UNIQUE_USERS = 18;
const ADMIN_EXCEL_ROW = 9;

function formattedCell(worksheet, address) {
  const cell = worksheet[address];
  return cell ? String(XlsxPkg.utils.format_cell(cell)) : '';
}

function readAccounts(path) {
  const workbook = XlsxPkg.readFile(path, { cellDates: false, raw: false });
  const sheetName = workbook.SheetNames[0];
  const worksheet = sheetName ? workbook.Sheets[sheetName] : null;
  const rangeAddress = worksheet?.['!ref'];
  if (!worksheet || !rangeAddress || !formattedCell(worksheet, 'A1').trim() || !formattedCell(worksheet, 'B1').trim()) {
    throw new Error('Workbook is missing the confirmed header row or the first two columns.');
  }

  const range = XlsxPkg.utils.decode_range(rangeAddress);
  if (range.e.c < 1 || range.e.r < 1) throw new Error('Workbook has no credential rows in columns A and B.');

  const byUsername = new Map();
  let sourceRows = 0;
  let duplicateRowsMerged = 0;
  for (let excelRow = 2; excelRow <= range.e.r + 1; excelRow += 1) {
    const username = formattedCell(worksheet, `A${excelRow}`).normalize('NFKC').trim();
    const password = formattedCell(worksheet, `B${excelRow}`);
    if (!username && !password.trim()) continue;
    if (!username || !password.trim()) throw new Error(`Incomplete credential pair at spreadsheet row ${excelRow}.`);
    if (/[\u0000-\u001f\u007f]/u.test(username)) throw new Error(`Invalid username at spreadsheet row ${excelRow}.`);
    if (Buffer.byteLength(username, 'utf8') > MAX_USERNAME_BYTES || Buffer.byteLength(password, 'utf8') > MAX_PASSWORD_BYTES) {
      throw new Error(`Credential length exceeds supported limits at spreadsheet row ${excelRow}.`);
    }

    sourceRows += 1;
    const role = excelRow === ADMIN_EXCEL_ROW ? 'admin' : 'user';
    const key = username.toLocaleLowerCase('vi');
    const existing = byUsername.get(key);
    if (existing) {
      if (existing.password !== password || existing.role !== role) {
        throw new Error(`Conflicting duplicate username at spreadsheet row ${excelRow}.`);
      }
      existing.duplicateRows += 1;
      duplicateRowsMerged += 1;
    } else {
      byUsername.set(key, { username, password, role, duplicateRows: 0 });
    }
  }

  const accounts = [...byUsername.values()];
  const adminCount = accounts.filter((account) => account.role === 'admin').length;
  if (sourceRows !== EXPECTED_DATA_ROWS || accounts.length !== EXPECTED_UNIQUE_USERS || duplicateRowsMerged !== 1 || adminCount !== 1) {
    throw new Error('Workbook structure differs from the confirmed import: expected 19 data rows, one identical duplicate, 18 unique users and one admin on row 9.');
  }
  return { accounts, duplicateRowsMerged };
}

async function importAccounts(path) {
  const { accounts, duplicateRowsMerged } = readAccounts(path);
  const hashedAccounts = [];
  for (const account of accounts) {
    hashedAccounts.push({
      username: account.username,
      displayName: account.username,
      passwordHash: await hashPassword(account.password),
      role: account.role,
    });
  }

  await initializeDatabase();
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    for (const account of hashedAccounts) {
      const [existingRows] = await connection.execute(
        'SELECT id FROM excelqr_users WHERE username = ? LIMIT 1 FOR UPDATE',
        [account.username],
      );
      if (existingRows[0]) {
        const userId = existingRows[0].id;
        await connection.execute(
          `UPDATE excelqr_users
           SET email = NULL, display_name = ?, password_hash = ?, role = ?, status = 'approved',
               rejection_reason = NULL, reviewed_at = UTC_TIMESTAMP(3), reviewed_by = NULL
           WHERE id = ?`,
          [account.displayName, account.passwordHash, account.role, userId],
        );
        await connection.execute('DELETE FROM excelqr_sessions WHERE user_id = ?', [userId]);
      } else {
        await connection.execute(
          `INSERT INTO excelqr_users
             (id, username, email, display_name, password_hash, role, status, reviewed_at)
           VALUES (?, ?, NULL, ?, ?, ?, 'approved', UTC_TIMESTAMP(3))`,
          [randomUUID(), account.username, account.displayName, account.passwordHash, account.role],
        );
      }
    }
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
    await pool.end();
  }

  console.log(JSON.stringify({ importedUniqueAccounts: hashedAccounts.length, adminAccounts: hashedAccounts.filter((account) => account.role === 'admin').length, duplicateRowsMerged }));
}

const workbookPath = process.argv[2];
if (!workbookPath) {
  console.error('Usage: node scripts/import-login-workbook.mjs <workbook-path>');
  process.exitCode = 2;
} else {
  importAccounts(workbookPath).catch((error) => {
    const code = typeof error?.code === 'string' ? error.code : 'IMPORT_FAILED';
    console.error(`Credential import stopped safely (${code}); no username or password was printed.`);
    process.exitCode = 1;
  });
}
