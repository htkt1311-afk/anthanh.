import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const serverEntry = fileURLToPath(new URL('../server/index.mjs', import.meta.url));
const viteEntry = fileURLToPath(new URL('../node_modules/vite/bin/vite.js', import.meta.url));
const apiPort = 3001;
let stopping = false;
const children = [];

function stopChildren(signal = 'SIGTERM') {
  if (stopping) return;
  stopping = true;
  for (const child of children) {
    if (child.exitCode === null && !child.killed) child.kill(signal);
  }
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => stopChildren(signal));
}

function watchChild(child, label) {
  child.once('error', (error) => {
    console.error(`${label} could not start: ${error.code ?? 'process error'}`);
    process.exitCode = 1;
    stopChildren();
  });
  child.once('exit', (code, signal) => {
    if (!stopping) {
      console.error(`${label} stopped unexpectedly (${signal ?? code ?? 'unknown'}).`);
      process.exitCode = code && code > 0 ? code : 1;
      stopChildren();
    }
  });
}

const api = spawn(process.execPath, [serverEntry], {
  cwd: projectRoot,
  env: { ...process.env, API_PORT: String(apiPort) },
  stdio: 'inherit',
});
children.push(api);
watchChild(api, 'Auth API');

let ready = false;
for (let attempt = 0; attempt < 120 && !stopping; attempt += 1) {
  if (api.exitCode !== null) break;
  try {
    const response = await fetch(`http://127.0.0.1:${apiPort}/_app/health`, { signal: AbortSignal.timeout(1_000) });
    if (response.ok) { ready = true; break; }
  } catch {
    // The API is still starting; continue checking its readiness endpoint.
  }
  await delay(500);
}

if (!ready) {
  if (!stopping) console.error('Auth API did not become ready; check managed MySQL and server startup output.');
  process.exitCode = 1;
  stopChildren();
} else if (!stopping) {
  const vite = spawn(process.execPath, [viteEntry, '--host', '0.0.0.0', '--port', '3000', '--strictPort'], {
    cwd: projectRoot,
    env: process.env,
    stdio: 'inherit',
  });
  children.push(vite);
  watchChild(vite, 'Vite Preview');
  await new Promise((resolve) => vite.once('exit', resolve));
  stopChildren();
}

await Promise.all(children.map((child) => new Promise((resolve) => {
  if (child.exitCode !== null) return resolve();
  child.once('exit', resolve);
  const timer = setTimeout(() => { if (child.exitCode === null) child.kill('SIGKILL'); resolve(); }, 9_000);
  timer.unref();
})));
