# Kế hoạch — Đăng nhập bằng danh sách Excel QR

## Phạm vi đã xác nhận

Người dùng yêu cầu tắt đăng ký/bootstrap và chỉ cho phép đăng nhập bằng tên đăng nhập/mật khẩu trong `FileDangnhap.xlsx`. Người dùng xác nhận cột A là username, cột B là password, dòng 1 là tiêu đề, dòng Excel số 9 là tài khoản admin, và các giá trị số của cột password được dùng đúng như đang hiển thị. Workbook có 19 dòng dữ liệu, một cặp trùng y hệt ở dòng 6 và 17; sẽ nhập một bản của cặp trùng, còn lại 18 tài khoản duy nhất: dòng 9 là admin, các dòng khác là user đã duyệt.

DB hiện có một tài khoản cũ ở trạng thái chờ duyệt không khớp username trong file và không có phiên đang hoạt động. Giữ nguyên bản ghi, không xóa; vì tài khoản không có username nằm trong danh sách, máy chủ sẽ không cho đăng nhập bằng nó. Tài khoản cũ không được chuyển thành tài khoản file.

## Cách triển khai

Thêm migration additive, có phiên bản, để thêm cột `username` nullable và unique cho bảng người dùng, đồng thời cho phép `email` null để tài khoản workbook không cần email. Không xóa các bản ghi hoặc session cũ. Mọi lần xác thực session/login chỉ chấp nhận username có trong bảng và tài khoản đang được duyệt; các user cũ không có username bị từ chối an toàn.

Xóa hoàn toàn màn đăng ký, trường mã bootstrap và API đăng ký/bootstrap khỏi luồng hoạt động. Màn đăng nhập chỉ có username/password. API xác thực truy vấn theo username, xác minh scrypt constant-time, giữ CSRF và cookie session hiện tại. Tài khoản workbook được nhập trực tiếp qua script một lần: đọc dòng 1 làm header, dùng giá trị hiển thị của ô Excel, trim username, giữ password đúng như file, gộp cặp username/password trùng y hệt, dừng nếu có username trùng nhưng password khác, băm password bằng cùng format scrypt, và ghi batch trong transaction. Script không in, xuất file hay lưu mật khẩu rõ vào workspace.

Dòng Excel số 9 được gán `admin` và `approved`; các dòng còn lại là `user` và `approved`. Admin API chỉ liệt kê/quản lý tài khoản có username; quyền quản trị chỉ thuộc tài khoản dòng 9. Không đọc credential cũ từ bootstrap secret và không dùng các biến đó trong mã mới. Không xuất bản website và không chuyển mã sang GitHub trong thay đổi này.

Lưu ý kiến trúc: Excel và QR vẫn xử lý cục bộ trong trình duyệt để không gửi tệp lên server. Xác thực bảo vệ luồng giao diện và API quản trị; nó không thể ngăn người tải mã client tái sử dụng logic QR ngoài website. Luồng đăng nhập hiện chưa có rate limit; cần bổ sung giới hạn tần suất ở gateway/API trước khi mở website công khai.

## Cấu trúc dự án

- `src/auth/AuthScreens.tsx`: chỉ hiển thị đăng nhập username/password và các trạng thái phiên.
- `src/auth/api.ts`, `useAuthSession.ts`, `types.ts`: giao tiếp API và kiểu người dùng theo username.
- `src/auth/AdminDashboard.tsx`: giao diện admin hiện hữu, hiển thị username thay cho email.
- `src/App.tsx`, `src/styles.css`: giữ công cụ QR, bỏ entry đăng ký/bootstrap.
- `server/index.mjs`: session, CSRF, username login và endpoint admin; không có register/bootstrap route.
- `server/db.mjs`: migration additive thêm username.
- `server/passwords.mjs`: hash/verify scrypt dùng chung giữa server và importer.
- `scripts/import-login-workbook.mjs`: importer chạy thủ công, chỉ lưu hash trong MySQL, không kèm workbook/credential trong Git.
- `TODO.md`: điều kiện đầu ra và tiến độ.

## Thiết kế giao diện

Giữ phong cách giấy–editorial hiện tại: nền kem, hành động đất nung, trạng thái teal và typography hiện có. Màn đăng nhập tối giản, ưu tiên username/password, báo lỗi chung để không tiết lộ tài khoản có tồn tại hay không. Xóa các nút và nội dung đăng ký/bootstrap khỏi UI.
